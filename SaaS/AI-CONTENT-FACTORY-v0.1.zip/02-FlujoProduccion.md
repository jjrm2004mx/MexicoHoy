# Flujo de Producción

## Pipeline v0.1

Tema ↓ Investigación ↓ Guion IA ↓ Revisión editorial ↓ Avatar IA ↓
Edición ↓ Exportación MP4 ↓ Metadata YouTube ↓ Publicación ↓ Analytics

## Convención archivos

Ejemplo:

MH5M-260616-001-SEGURIDAD.mp4

Formato: - Proyecto - Fecha - Número episodio - Tema
