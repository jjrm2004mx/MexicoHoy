# Backlog Scrum

# EPIC-001 - Motor de generación de contenido

## HU-001 Investigación automática

Como creador de contenido, quiero obtener información relevante
automáticamente, para reducir tiempo de investigación.

Criterios: - Identificar temas relevantes. - Resumir información. -
Clasificar prioridad.

------------------------------------------------------------------------

## HU-002 Generador de guiones IA

Como productor, quiero generar guiones estructurados, para mantener un
formato consistente.

Criterios: - Introducción atractiva. - Contexto. - Datos. -
Explicación. - Cierre.

------------------------------------------------------------------------

# EPIC-002 - Producción Multimedia

## HU-003 Generación visual

Crear: - Miniaturas - Imágenes - Presentaciones

------------------------------------------------------------------------

## HU-004 Avatar IA

Convertir guiones en videos usando presentadores virtuales.

------------------------------------------------------------------------

# EPIC-003 - Publicación YouTube

Automatizar: - Títulos - Descripción - Tags - Categorías - Publicación

------------------------------------------------------------------------

# EPIC-004 - Analytics Engine

Analizar: - Vistas - CTR - Retención - Suscriptores
